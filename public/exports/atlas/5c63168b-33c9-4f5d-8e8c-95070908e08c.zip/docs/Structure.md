# Project Directory Structure

Below is the folder and file layout designed for this project:

```
frontend/
frontend/src/
frontend/src/components/
frontend/src/App.jsx
backend/
backend/api/
backend/main.py
database/
database/schema.sql
docs/
docs/Roadmap.md
README.md
```
