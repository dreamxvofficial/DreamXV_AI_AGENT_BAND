# Placeholder for schema.sql
