# Project Directory Structure

Below is the folder and file layout designed for this project:

```
src/
src/backend/
src/backend/fastapi/
src/frontend/
src/frontend/react/
src/shared/
src/.gitignore
src/README.md
```
