# Project Directory Structure

Below is the folder and file layout designed for this project:

```
Assets/
Assets/Images/
Assets/Sounds/
Assets/Fonts/
Backend/
Backend/FastAPI/
Backend/FastAPI/models/
Backend/FastAPI/routers/
Frontend/
Frontend/src/
Frontend/src/components/
Frontend/src/pages/
Frontend/src/services/
README.md
requirements.txt
package.json
```
