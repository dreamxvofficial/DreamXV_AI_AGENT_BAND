# Production Workflow & Dependencies

## Step-by-Step Workflow
1. Set up project structure and initialize git repository
2. Design and set up database schema using Supabase
3. Develop FastAPI endpoints for resource management
4. Design UI/UX mockups for key screens
5. Build React components for main game interface
6. Implement scavenging mechanics and resource management
7. Develop basic shooting mechanics and enemy AI
8. Conduct unit tests for backend services
9. Perform integration tests for frontend/backend communication
10. Debug and fix identified issues
11. Deploy backend to cloud service (e.g., Heroku, AWS)
12. Deploy frontend to static hosting (e.g., Netlify, Vercel)

## Core Dependency Graph
- AuthService -> Database -> API -> Frontend
- ResourceService -> Database -> API -> Frontend
- UserService -> Database -> API -> Frontend
