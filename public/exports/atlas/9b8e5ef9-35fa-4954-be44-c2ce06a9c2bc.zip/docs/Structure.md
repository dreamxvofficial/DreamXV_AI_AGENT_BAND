# Project Directory Structure

Below is the folder and file layout designed for this project:

```
src/
src/components/
src/pages/
src/services/
src/utils/
backend/
backend/models/
backend/routers/
backend/core/
```
