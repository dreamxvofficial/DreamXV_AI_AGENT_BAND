# Project Directory Structure

Below is the folder and file layout designed for this project:

```
frontend/
frontend/src/
backend/
backend/api/
README.md
```
