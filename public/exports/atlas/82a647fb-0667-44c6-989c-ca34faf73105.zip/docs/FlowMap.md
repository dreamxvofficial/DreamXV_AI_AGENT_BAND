# Production Workflow & Dependencies

## Step-by-Step Workflow
1. Create Database
2. Build API

## Core Dependency Graph
- Database -> API
