# Project Tasks

## Critical Path Tasks (MVP)
- [ ] Setup Git repository

## Optional Tasks
- [ ] Add dark mode

## Future Expansion
- [ ] Add caching
