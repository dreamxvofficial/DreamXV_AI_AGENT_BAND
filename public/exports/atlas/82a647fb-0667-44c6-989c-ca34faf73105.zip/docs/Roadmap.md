# Development Roadmap

## Phase 1: Project Setup
- [ ] Setup repository
- [ ] Initialize folders

## Phase 2: Database Setup
- [ ] Setup Supabase database

