# Project Directory Structure

Below is the folder and file layout designed for this project:

```
src/
src/components/
src/pages/
src/services/
src/utils/
backend/
backend/api/
backend/database/
backend/auth/
public/
package.json
README.md
server.py
.env
```
