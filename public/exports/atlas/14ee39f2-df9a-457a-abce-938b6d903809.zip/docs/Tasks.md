# Project Tasks

## Critical Path Tasks (MVP)
- [ ] Set up project structure using React for frontend and FastAPI for backend
- [ ] Develop scavenging resource system
- [ ] Implement zombie shooting mechanics
- [ ] Conduct unit tests for core functionalities
- [ ] Deploy backend services using FastAPI
- [ ] Deploy frontend using React

## Optional Tasks
- [ ] Add detailed character customization options
- [ ] Include additional zombie types with unique behaviors
- [ ] Implement a tutorial level for new players

## Future Expansion
- [ ] Expand the game world with more locations and quests
- [ ] Add multiplayer functionality for cooperative play
- [ ] Develop mobile versions for iOS and Android
