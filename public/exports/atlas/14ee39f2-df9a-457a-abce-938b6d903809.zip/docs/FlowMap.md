# Production Workflow & Dependencies

## Step-by-Step Workflow
1. Set up project structure
2. Develop core game loop functionalities
3. Design and implement UI elements
4. Test individual components
5. Integrate and test frontend and backend
6. Deploy services to production

## Core Dependency Graph
- AuthService -> Database -> API -> Frontend
- ScavengingSystem -> Resources -> PlayerInventory -> UI
- ZombieShootingMechanic -> PlayerCharacter -> CombatUI -> Backend
