# Project Directory Structure

Below is the folder and file layout designed for this project:

```
Mock list item 1
Mock list item 2
Mock list item 3
```
