# Project Tasks

## Critical Path Tasks (MVP)
- [ ] Map camera behaviors
- [ ] Code primary action/move behaviors
- [ ] Ensure stable launch build

## Optional Tasks
- [ ] Design simple settings panel
- [ ] Add ambient sound layers

## Future Expansion
- [ ] Create secondary levels
- [ ] Deploy multi-platform exports
