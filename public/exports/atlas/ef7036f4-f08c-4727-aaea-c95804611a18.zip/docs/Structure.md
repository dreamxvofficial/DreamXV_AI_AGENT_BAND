# Project Directory Structure

Below is the folder and file layout designed for this project:

```
Assets/
Assets/Scripts/
Assets/Prefabs/
Assets/Materials/
Assets/Animations/
Assets/Scenes/
Docs/
Docs/GDD.md
Docs/Roadmap.md
Docs/Tasks.md
README.md
```
